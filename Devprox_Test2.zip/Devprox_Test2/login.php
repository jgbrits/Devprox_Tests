
<?php	
	$servername = 'localhost';
	$username = 'root';
	$password = '';
	$dbname = 'dbdevproxtest2';
	$tablename = 'csv_import';
?>
	
