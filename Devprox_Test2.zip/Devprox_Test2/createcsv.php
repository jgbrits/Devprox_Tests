<?php


	//Names and surnames arrays
	$names = array("Andre","Bernard Lee","Carel","Dean","Ernst","Francois","Geraldine","Handre","Iwan","Johan George","Katryn","Louise","Mary Anne","Nancy","Owen","Pete","Quirk","Ramond","Sean Raymond","Tyron James");
	$surnames = array("Arendse","Bieldt","Carmichael","De Wet","Eden","Farraday","Griessel","Handel","Irvin","Jansen","Kelvin","Le Roux","Mensch","Naidoo","Olien","Pieterse","Quinn","Rembrandt","Stevenson","van Zuydam");
	
	//Variables related to date
	$monthsWith30days = array(4,6,9,11);
	$monthsWith31days = array(1,3,5,7,8,10,12);
	$currentDate = date("d/m/Y");
	$currentDay = substr($currentDate,0,2);
	$currentMonth = substr($currentDate,3,2);
	$currentYear = substr($currentDate,6,4);
	
	$validStartYear = $currentYear - 100;
	$validEndYear = $currentYear - 1;

	
	//Variables to hold randomly generated birthdates and status of a birhdate taken by a record
	$dobArray = array();
	$dateTaken = array();
	
	//Variables to hold nane-surname pairs
	$nameSurnameArray = array();
	
	//Array to hold records
	$recordArray = array();
	$recordTaken = array();
	
	//File variables
	$myfile = fopen("output_file/output.csv", "w") or die("Unable to open file!");
	$header = "Id,Name,Surname,Initials,Age,DateOfBirth" . "\r\n";
	fwrite($myfile, $header);
	
	//Variable to hold status of a number input error occuring
	$numberErr = $submitErr = "";

	
	//Was form submitted?
	if ($_SERVER["REQUEST_METHOD"] == "POST") 
	{
		
		
		//Validate number, test for empty field or the number 0
		if (empty($_POST["numberOfRecords"])) 
		{
			$numberErr = "Number is required. Numbers must be greater than zero.";
			$submitErr = "There's and error in your input! See the error below.";
		} 
		//Test for negative numbers
		else if (($_POST["numberOfRecords"]) < 0)
		{
			$numberErr = "Only positive numbers allowed.";
			$submitErr = "There's and error in your input! See the error below.";
		}
		else 
		{
			$num = test_input($_POST["numberOfRecords"]);
			
			// check if input only contains numbers
			if (!preg_match("/[1-9]/",$num)) 
			{
				$numberErr = "Only numbers allowed."; 
				$submitErr = "There's and error in your input! See the error below.";
			}
		
			//If everything is fine, use the input and create the file		
			else
			{
				
				//Create array of records
				createRecordArray($num);

			
				//Write to text file
				createCSV($num);	

				header("Location: downloadfile.php");
				exit;				
			}
		}	
	}
	
	
	
	///////////FUNCTIONS/////////////
	
	
	//Input: Num of unique records needed
	function createRecordArray($fnumRecords)
	{
		global $dobArray, $dateTaken, $nameSurnameArray, $recordArray, $recordTaken, $currentYear;
		
		//100 years x 12 months x 30 days = pool of 36000 dates
		//1000 000 unique records needed
		//pool of 400 name-surname pairs
		//400 unique name-surname pairs x 2500 unique dates = 1000 000 unique records
		
		if ($fnumRecords > 400)
		{
			$numDatesNeeded = ceil($fnumRecords/400);  
		}
		else
		{
			$numDatesNeeded = 1;
		}
				
		
		//array of dates for last 100 years. Thus pool of 36000 dates in $dobArray
		createDOBArray();
		//Create name-surname pairs
		createNameSurnameArray();
		
		
		//Initialize values of dates already taken to false
		for($k = 0; $k < count($dobArray); $k++)
		{
			$dateTaken[$k] = false;
		}
		
		
		//Loop through the pool of name-surname pairs
		for($i = 0; $i < count($nameSurnameArray); $i++)
		{
			//Loop through the number of dates needed to create $fnumRecords
			for($j = 0; $j < $numDatesNeeded; $j++)
			{
				//Get a random birthday
				$dob = getRandomDOB();

				//Build the record to be saved in the array

				$buildRecord = "\"" . $nameSurnameArray[$i] . "\"" . "," . "\"" . getInitials($nameSurnameArray[$i]) . "\"" . "," . "\"" . calculateAge($dob) . "\"" . "," . "\"" . $dob . "\"";
				
				//Add the record to the records array
				 array_push($recordArray,$buildRecord);
			}
			
			//Reset dates already taken for next round
			for($m = 0; $m < count($dobArray); $m++)
			{
				$dateTaken[$m] = false;
			}
		}
		
		
		//Initialize values of records already taken to false
		for($k = 0; $k < count($recordArray); $k++)
		{
			$recordTaken[$k] = false;
		}
	

	}
	
	
	//Function to calculate current age. Input: date of birth  Output: Age
	function calculateAge($fBirthDate)
	{
		global $currentDay, $currentMonth, $currentYear;
		
		$birthDay = substr($fBirthDate,0,2);
		$birthMonth = substr($fBirthDate,3,2);
		$birthYear = substr($fBirthDate,6,4);
		
		
		if(($birthDay > $currentDay) && ($birthMonth == $currentMonth))
		{
			$age = $currentYear - $birthYear - 1;
		}
		else if($birthMonth > $currentMonth)
		{
			$age = $currentYear - $birthYear - 1;
		}
		else
		{
			$age = $currentYear - $birthYear;
		}
		
		return $age;	
	}
	
	
	//Function to create valid birth dates
	function createDOBArray()
	{
		global $dobArray, $validStartYear, $validEndYear, $monthsWith30days, $monthsWith31days;
		
		//Iterate throught the years
		for($y = $validStartYear; $y <= $validEndYear; $y++ )
		{
			//Iterate through the months
			for ($m = 1; $m <=12; $m++)
			{
				
				
				//Iterate through the days based on the month and year	
				if (in_array($m, $monthsWith30days))
				{
					//Iterate through the days
					for ($d = 1; $d <=30; $d++)
					{
						//Format the output
						$d = sprintf('%02d', $d);
						//Format the output
						$m = sprintf('%02d', $m);
		
						//Build the full date
						$dob = $d . "/" . $m . "/" . $y;
						
						array_push($dobArray,$dob);
					}
				} 
				else if (in_array($m, $monthsWith31days))
				{
					//Iterate through the days
					for ($d = 1; $d <=31; $d++)
					{
						//Format the output
						$d = sprintf('%02d', $d);
						
						//Format the output
						$m = sprintf('%02d', $m);
		
						//Build the full date
						$dob = $d . "/" . $m . "/" . $y;
						
						array_push($dobArray,$dob);
					}
				}
				else
				{
					if (fmod($y,4) == 0)
					{
						//Iterate through the days
						for ($d = 1; $d <=29; $d++)
						{
							//Format the output
							$d = sprintf('%02d', $d);
							
							//Format the output
							$m = sprintf('%02d', $m);
		
							//Build the full date
							$dob = $d . "/" . $m . "/" . $y;
						
							array_push($dobArray,$dob);
						}
					}
					else
					{
						//Iterate through the days
						for ($d = 1; $d <=28; $d++)
						{
							//Format the output
							$d = sprintf('%02d', $d);
							
							//Format the output
							$m = sprintf('%02d', $m);
		
							//Build the full date
							$dob = $d . "/" . $m . "/" . $y;
						
							array_push($dobArray,$dob);
						}
					}
				}

			}
		}
		
	}
	
	
	
	//Function to create 400 pairs of names and surnames
	function createNameSurnameArray()
	{
		global $nameSurnameArray, $names, $surnames;
		
		
		for($i = 0; $i < 20; $i++)
		{
			for($j = 0; $j < 20; $j++)
			{
				$record = $names[$i] . "\"" . "," ."\"" . $surnames[$j];
				array_push($nameSurnameArray,$record); 
			}
		}
		
	}
	
	
	
	//Function to get a random birthday from an array of generated valid birth dates
	function getRandomDOB()
	{
		global $dobArray, $dateTaken;
		
	
		$randomDOBIndex = mt_rand(0,count($dobArray)-1);
		
		while ($dateTaken[$randomDOBIndex] === true)
		{
			$randomDOBIndex = mt_rand(0,count($dobArray)-1);	
		}
		
		$dateTaken[$randomDOBIndex] = true;
		return $dobArray[$randomDOBIndex]; 		
	}
		
	
	
	//Function to get initials from a name  Input: name  Output: Initials
	function getInitials($fName)
	{
		$initials = "";
		$firstInitial = substr($fName,0,1);
		$initials = $firstInitial;
		
		
		//Test only for the name part, leave out the surname part
		if ((strpos($fName," ") != FALSE)&&(strpos($fName,",") > strpos($fName," ")))
		{
			$secondInitial = substr($fName, strpos($fName," ") + 1, 1);
			$initials .= $secondInitial;
		}
		
		return $initials;
	}
	
	
	
	//Function to generate CSV file  Input: number of records required  Output: CSV file with random records
	function createCSV($fnumRecords)
	{
			global $myfile, $recordArray, $recordTaken;
			//Initialize
			$writeErr = false;
						
			//Loop through the number of records to be written
			for($i = 0; $i < $fnumRecords; $i++)
			{
				
				//Select records at random to be inserted into the file
				$randomRecordIndex = mt_rand(0,count($recordArray)-1);
				
				//test if record was already inserted or not before to avoid inserting duplicate records
				while ($recordTaken[$randomRecordIndex] === true)
				{
					$randomRecordIndex = mt_rand(0,count($recordArray)-1);
				}
				
				$record = $recordArray[$randomRecordIndex];
				$recordTaken[$randomRecordIndex] = true;
				$id = $i + 1;
		
				//Build the record to be saved in the text file
				if ($i < ($fnumRecords-1))
				{
					$record = "\"" . $id . "\"" . "," . $record . "\r\n";
				}
				//Last record should not have an EOL character
				else
				{
					$record = "\"" . $id . "\"" . "," . $record;
				}
				 
				
				//Write the record to the CSV file
				if (fwrite($myfile, $record) === false) 
				{
					$writeErr = true;
				}

			}
			
			//Test whether the records were written or if there was an error
			/*if($writeErr === true)
			{				
				echo "<script type='text/javascript'>alert('There was an error writing to the CSV file!')</script>";	
			}
			else
			{	
				echo "<script type='text/javascript'>alert('CSV File Created successfully!')</script>";
			}*/
			
			//Close the file
			fclose($myfile);
	}
	
	
	//Function to sanitize the user input before submitting to database
	function test_input($data) 
	{
		$data = trim($data);
		$data = stripslashes($data);
		$data = htmlspecialchars($data);
		return $data;
	}


?>