	  
	  //Function to validate all the form fields
	  function validate(form)
      {
        fail  = validateNumber(form.numberOfRecords.value)

        if   (fail == "")   return true
        else { alert(fail); return false }
      }
	  
	  	  
      //Function to validate the number field
      function validateNumber(field)
      {
        if (field == "") return "No number was entered.\n"
		else if (field <= 0) return "Only positive numbers greater than zero allowed.\n"
        else if (! /[0-9]/.test(field))
          return "May only contain numbers. No letters or special characters allowed\n"
        return ""
      }