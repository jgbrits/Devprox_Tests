In your "php.ini" file:

1. search for the file_uploads directive, and set it to On

2. search for the upload_max_filesize directive, increase it to 500M

3. search for the post_max_size directive, increase it to 500M

4. search for the memory_limit directive, increase it to 1280M

5. search for the max_input_time directive, increase it to 1800



