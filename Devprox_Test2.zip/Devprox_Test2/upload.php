<?php

//File related variables
$target_dir = "uploads/";
$target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
$fileType = pathinfo($target_file,PATHINFO_EXTENSION);
$uploadOk = 1;
$fileErrMsg = "";

// Allow only certain file formats
if($fileType != "csv") 
{
    echo "<script type='text/javascript'>alert('Sorry, only CSV files are allowed!')</script>";
	echo "Sorry, only CSV files are allowed.";
    $uploadOk = 0;
}


// Check if $uploadOk is set to 0 by an error
if ($uploadOk == 0) 
{
    echo "<script type='text/javascript'>alert('Sorry an error occured, your file was not uploaded!')</script>";
	echo "Sorry, your file was not uploaded.";

} 
// if everything is ok, try to upload file
else 
{
    if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) 
	{
        echo "<script type='text/javascript'>alert('The file ". basename( $_FILES["fileToUpload"]["name"]). " has been uploaded to the server.')</script>";
		echo "The file ". basename( $_FILES["fileToUpload"]["name"]). " has been uploaded to the server.";
		
		//Write the contents of the file to a database
		writeToDB();		
    }
	else
	{	
		echo "<script type='text/javascript'>alert('Sorry an error occurred. Your file could not be uploaded. Please contact the system admin.')</script>";
    }
}


function writeToDB()
{
	global $target_file;
	include 'login.php';
	$fileArray = array();  //array to hold the contents of the CSV file in memory
	
	if ($_SERVER["REQUEST_METHOD"] == "POST") {
		
		//////INSERT RECORDS INTO DATABASE//////
	
  
		//Create connection to mySQL
		$conn = new mysqli($servername, $username, $password);
	
  
		//Check connection to mySQL
		if ($conn->connect_error)
		{
			die("<script type='text/javascript'>alert('Coulnd't connect to database. Please check your connection settings!')</script>");
		} else {
			//echo "connected successfully!"; 
		}
	
	
		// Create database
		$sql = "CREATE DATABASE IF NOT EXISTS $dbname";
		//Execute SQL query
		if ($conn->query($sql) === TRUE) 
		{
			//echo "Database $dbname created successfully";
		} 
		else 
		{
			//echo "Error creating database: " . $conn->error;
		}
		
		
		// Create connection to database
		$conn = new mysqli($servername, $username, $password, $dbname);
		
		// Check connection to database
		if ($conn->connect_error) 
		{
			die("<script type='text/javascript'>alert('Coulnd't connect to database. Please check your connection settings!')</script>");
		}
		
	  
		//Create table
		$sql = "CREATE TABLE IF NOT EXISTS $tablename (
			id INT NOT NULL, 
			name VARCHAR(32) NOT NULL,
			surname VARCHAR(32) NOT NULL,
			initials VARCHAR(2) NOT NULL,
			age INT NOT NULL,
			dob DATE NOT NULL,
			PRIMARY KEY (ID)
		)ENGINE=MyISAM";
		
		//Execute SQL query
		if ($conn->query($sql) === TRUE) 
		{
			//echo "Table $tablename created successfully";
		} 
		else 
		{
			//echo "Error creating table: " . $conn->error;
		} 
		
		   
		//Build SQL query to import csv file into database
		$sql = "LOAD DATA LOCAL INFILE '$target_file' INTO TABLE $tablename FIELDS TERMINATED BY ',' ENCLOSED BY '\"' LINES TERMINATED BY '\r\n' IGNORE 1 LINES (id,name,surname,initials,age,@var1) set dob = STR_TO_DATE(@var1, '%d/%m/%Y')";
		
		//Execute SQL query
		if ($conn->query($sql) === TRUE) 
		{
			//Get the number of records inserted into the table
			$numOfRecordsInserted = $conn->affected_rows;
			
			//Let the user know how many records were successfully imported			
			echo "<script type='text/javascript'>alert('$numOfRecordsInserted records inserted to the database!')</script>";
			echo "$numOfRecordsInserted records inserted into the database!";	
		} 
		else 
		{
				
			echo "<script type='text/javascript'>alert('Could not load data from your file into database. Please contact the system admin.')</script>";
			echo "Could not load data from your file into database. Please contact the system admin.";
						
		} 

	}
		
		
		
}
	
?>
