<?php
$filename = "output_file/output.csv";

header("Content-Length: " . filesize($filename));
header('Content-Type: application/octet-stream');
header('Content-Disposition: attachment; filename=output.csv');

readfile($filename);
?>