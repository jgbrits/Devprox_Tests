<!DOCTYPE html>
<html>
  <head>
	
	<link href='https://fonts.googleapis.com/css?family=Sniglet|Raleway:900' rel='stylesheet'>
	<link rel="stylesheet" type="text/css" href="mystyle.css">
	<script src="validate.js"></script>
	<?php require_once("createcsv.php");?>
	
	
    <title>DEVPROX TEST 1</title>
  
  </head>
  
  
  <body>
  
  	<noscript>
		<h2 class = "error">JavaScript is disabled! Please enable JavaScript in your web browser for the best experience! Some functionality may not work otherwise</h2>
	</noscript>
  
<!--HTML form for input of number of records to generate-->

	<div align="center" class ="signup">
      <h2 align="center">Generate Records</h2>
	  <h3 align="center" class = "error"><?php echo $submitErr?></h3>
      <form method="post" action="index.php" onsubmit="return validate(this)">
	    
		  <div align="center">
		  <label>Enter the number of random records to be created for the CSV file</label>
          <input id="numField" type="number" placeholder="Number" name="numberOfRecords" pattern = "\[0-9]\" required autofocus>
		  <label id="numberErrField" class = "error"> <?php echo $numberErr;?>  </label>
		  </div>
		 
		  <div align="center">
		  <input type="submit" value="GENERATE">
		  </div> 
      </form>
	</div>
	 

<!--HTML form to upload a CSV file to be saved to a database-->
	  
	<div align="center" class ="signup">
      <h2 align="center">Upload CSV file to Database</h2>
	  <form action="upload.php" method="post" enctype="multipart/form-data">
		  <label>Select file to upload:</label>
		  <input type="file" name="fileToUpload" id="fileToUpload">
		  <input type="submit" value="Upload File" name="submit">
	  </form>
	</div>
	  
	  
	  
	  
	
  </body>
</html>




