<?php
	
	//Define variables and set to empty values
	$nameErr = $surnameErr = $idErr = $dobErr = $submitErr = "";
	$name = $surname = $id = $dob = "";	
	
	//Variables related to date
	$monthsWith30days = array(4,6,9,11);
	$monthsWith31days = array(1,3,5,7,8,10,12);


	//////SERVER-SIDE VALIDATION OF USER INPUT FIELDS//////
	
	
	if ($_SERVER["REQUEST_METHOD"] == "POST") 
	{
		
		
		//Validate name
		validateName();

		//Validate surname
		validateSurname();
		
		//Validate ID
		validateID();
		
		//Validate dob
		validateDOB();
		
		//Connect to database and insert record
		connectAndInsertDB();

	}
	
	
	
	//Function to validate the birthday
	function validateDOB()
	{
		global $dobErr, $dob;
		
		if (empty($_POST["dob"])) 
		{
			$dobErr = "Birth date is required";
		} 
		else 
		{
			$dob = test_input($_POST["dob"]);
			$id = test_input($_POST["id"]);
			
			$dobErr = validateDate($dob);
			$dobErr .= validateIDagainstDOB($id,$dob);
		}
	}
	
	//Function to validate the ID
	function validateID()
	{
		global $idErr, $id;
		
		if (empty($_POST["id"])) 
		{
			$idErr = "ID is required";
		} 
		else 
		{
			$id = test_input($_POST["id"]);
			
			// check if ID only contains numbers
			if ((!preg_match("/[0-9]/",$id)) || (strlen($id) != 13)) 
			{
				$idErr = "Only numbers allowed. ID must contain 13 digits"; 
			}
		}
	}
	
	//Function to validate the surname
	function validateSurname()
	{
		global $surnameErr, $surname;
		
		if (empty($_POST["surname"])) 
		{
			$surnameErr = "Surame is required";
		} 
		else 
		{
			$surname = test_input($_POST["surname"]);
			
			// check if surname only contains letters and whitespace
			if (!preg_match("/^[-a-zA-Z ]*$/",$surname)) 
			{
				$surnameErr = "Only letters, white spaces and hyphens allowed"; 
			}
		}
	}
	
	//Function to validate the name
	function validateName()
	{
		global $nameErr, $name;
		
		if (empty($_POST["name"])) 
		{
			$nameErr = "Name is required";
		} 
		else 
		{
			$name = test_input($_POST["name"]);
			
			// check if name only contains letters and whitespace
			if (!preg_match("/^[-a-zA-Z ]*$/",$name)) 
			{
				$nameErr = "Only letters, white spaces and hyphens allowed"; 
			}	
		}
	}
	
	
	//Function to validate the date of birth against the ID number
	function validateIDagainstDOB($fieldID, $fieldDOB)
    {
		  
		//get info from birthday
		$dDOB = (substr($fieldDOB,0,2))*1;
		$mDOB = (substr($fieldDOB,3,2)*1);
		$yDOB = (substr($fieldDOB,8,2)*1);
			
		//get info from ID
		$yID = (substr($fieldID,0,2))*1;
		$mID = (substr($fieldID,2,2)*1);
		$dID = (substr($fieldID,4,2)*1);
			
		if (($dDOB == $dID)&&($mDOB == $mID)&&($yDOB == $yID))
		{
			return "";
		}
			
		else
		{
			return "Your birthday does not match the first 6 digits in your ID.";
		}
     }
	
	
	//Function to validate the date of birth field
    function validateDate($field)
    {
		global $monthsWith30days, $monthsWith31days;
	
		//Test for correct input format
		if ((strlen($field) == 10)&&(($field[2] == "/")||($field[5] == "/")))
		{
							
			$d = (substr($field,0,2))*1;
			$m = (substr($field,3,2)*1);
			$y = (substr($field,6,4)*1);
			$date = date("Y/m/d");
			$curYear = date("Y");
			$curMonth = date("m");
			$curDay = date("d");
			$validMinYear = $curYear - 120;
			$validEndYear = $curYear - 1;
			
			
			//Test valid year minimum year
			if($y < $validMinYear)
			{
				return "Not a valid calendar date! You should have been long dead! ";
			}
			
			
			//Test for future dates
			if($y > $curYear)
			{
				return "Not a valid calendar date! Looks like you still need to be born! ";
			}
			else if((($y == $curYear)&&($m > $curMonth))||(($y == $curYear)&&($m == $curMonth)&&($d > $curDay)))
			{
				return "Not a valid calendar date! Looks like you still need to be born! ";
			}
			
			
			//Test valid month
			if(($m < 1) || ($m > 12) )
			{
				return "Not a valid calendar date! Months can only be between 1 and 12 ";
			}
			
			//Test for months with 30 days
			if (in_array($m, $monthsWith30days))
			{
				if (($d < 1) || ($d > 30))
				{
					return "Not a valid calendar date! This month can only have 30 days ";
				}
			}
			
			//Test for months with 31 days
			else if (in_array($m, $monthsWith31days))
			{
				if (($d < 1) || ($d > 31))
				{
					return "Not a valid calendar date! This month can only have 31 days ";
				}
				
			}
			else
			{
			
				//Test for leap years (February)
				if (fmod($y,4) == 0)
				{
					if (($d < 1) || ($d > 29))
					{
						return "Not a valid calendar date! Leap years has 29 days in February! ";
					}
				}
				//Test for non-leap years
				else 
				{
					if (($d < 1) || ($d > 28))
					{
						return "Not a valid calendar date! Non leap years only have 28 days in February! ";
					}
				}
			}
			
		//If none of the above were triggered, the date is valid
		return "";
      }
	  //Invalid date format
	  else
	  {
		  return "Please enter your birthday in the following format: dd/mm/yyyy. /'s should be included. ";
	  }
	}
	
	
	//Function to connect to and insert records into database
	function connectAndInsertDB()
	{
		global $nameErr, $surnameErr, $idErr, $dobErr, $submitErr;
		global $servername, $username, $password, $dbname, $tablename;
		global $name, $surname, $id, $dob;
		
		//Only if there was no error in the form fields, can the record be inserted into the database
		if(($nameErr == "")&&($surnameErr == "")&&($idErr == "")&&($dobErr == ""))
		{
			//Create connection to mySQL
			$conn = new mysqli($servername, $username, $password);
	
  
			//Check connection to mySQL
			if ($conn->connect_error)
			{
				//Let the user know that an error occurred on the server
				echo("<script type='text/javascript'>alert('An error occurred on the server. Please contact the help desk!')</script>");
				$submitErr = "An error occurred on the server. Please contact the help desk!";
				//die("Connection failed: " . $conn->connect_error);
			} 
			else
			{
				//echo "connected successfully to mySQL!"; 
			}
	
	
			// Create database
			$sql = "CREATE DATABASE $dbname";
			if ($conn->query($sql) === TRUE) 
			{
				//echo "Database $dbname created successfully";
			} 
			else 
			{
				//echo "Error creating database: " . $conn->error;
			}
			
			
			// Create connection to database
			$conn = new mysqli($servername, $username, $password, $dbname);
			
			// Check connection to database
			if ($conn->connect_error) 
			{
				//Let the user know that an error occurred on the server
				echo("<script type='text/javascript'>alert('An error occurred on the server. Please contact the help desk!')</script>");
				$submitErr = "An error occurred on the server. Please contact the help desk!";
				//die("Connection failed: " . $conn->connect_error);
			}
			else
			{
				//echo "connected successfully to database!"; 
			}
			
		  
			//Create table
			$sql = "CREATE TABLE $tablename (
				ID VARCHAR(13) NOT NULL, 
				name VARCHAR(32) NOT NULL,
				surname VARCHAR(32) NOT NULL,
				dob DATE NOT NULL,
				PRIMARY KEY (ID)
			)";
			
			//Check if table was created
			if ($conn->query($sql) === TRUE) 
			{
				//echo "Table $tablename created successfully";
			} 
			else 
			{
				//echo "Error creating table: " . $conn->error;
			} 
			
			
			//Get data from HTML form
			if (isset($_POST['name']) &&
				isset($_POST['surname']) &&
				isset($_POST['id']) &&
				isset($_POST['dob']))
			{				
				$name   	= mysqli_real_escape_string($conn,test_input($_POST["name"]));
				$surname    = mysqli_real_escape_string($conn,test_input($_POST["surname"]));
				$id 		= mysqli_real_escape_string($conn,test_input($_POST["id"]));
				$dob     	= mysqli_real_escape_string($conn,test_input($_POST["dob"]));
				
				//Build correct format of date for mySQL.  Use DATE_FORMAT("2017-06-15", "%d %M %Y") for displaying back into the format dd-MM-YYYY
				$dob = substr($dob,6,4) . "-" . substr($dob,3,2) . "-" . substr($dob,0,2);
			}
			
			
			//First test whether ID already exists, before inserting record into database
			$sql = "SELECT * FROM $tablename WHERE ID='$id'";
			$result = $conn->query($sql);
			$num_rows = $result->num_rows;

			if ($num_rows > 0)
			{
				$idErr = "ID already exists in the database. Make sure your ID is correct.";
				$submitErr = "Can't submit the form, please correct the errors in red!";
				//Display date in correct format in user input
				$dob = test_input($_POST["dob"]);
			}
			
			//If ID does not exist, insert the record into the database
			else
			{
				//Insert data into database table
				$sql = "INSERT INTO $tablename (ID, name, surname, dob) VALUES ($id, '$name', '$surname', '$dob')";
				//Test whether it was successfull
				if ($conn->query($sql) === TRUE) 
				{
					//Clear form input fields
					$name = "";
					$surname = "";
					$id = "";
					$dob = "";
				
					//Let the user know that the record was submitted successfully
					$submitErr = "Your information was submitted successfully!";
					echo "<script type='text/javascript'>alert('submitted successfully!')</script>";
				
				} 
				else 
				{
					//echo "Error inserting data: " . $conn->error;
					//Let the user know that there was an error in the input
					echo("<script type='text/javascript'>alert('An error occurred on the server. Please contact the help desk!')</script>");
					$submitErr = "An error occurred on the server. Please contact the help desk!";
				}
			}
		}  
		else
		{
			//Let the user know that there was an error in the input
			echo("<script type='text/javascript'>alert('There was an error/s in your input. Please fix the errors first!')</script>");
			$submitErr = "Can't submit the form, please correct the errors in red!";
		}
	}
	
	//Function to sanitize the user input before submitting to database
	function test_input($data) 
	{
		$data = trim($data);
		$data = stripslashes($data);
		$data = htmlspecialchars($data);
		return $data;
	}
	
	
?>