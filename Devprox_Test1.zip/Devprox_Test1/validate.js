	  
	  //Function to validate all the form fields
	  function validate(form)
      {
        fail  = validateName(form.name.value)
        fail += validateSurname(form.surname.value)
        fail += validateID(form.id.value)
        fail += validateDOB(form.dob.value)
		fail += validateIDagainstDOB(form.id.value, form.dob.value)

        if   (fail == "")   return true
        else { alert(fail); return false }
      }
	  
	  
	  //Function to validate the name field
      function validateName(field)
      {
        if (field == "") return "No name was entered.\n"
        else if (! /^[-a-zA-Z ]*$/.test(field))
          return "Name: Only letters, white spaces and hyphens allowed\n"
        return ""	
      }
	  
	  
      //Function to validate the surname field
      function validateSurname(field)
      {
        if (field == "") return "No surname was entered.\n"
        else if (! /^[-a-zA-Z ]*$/.test(field))
          return "Surname: Only letters, white spaces and hyphens allowed\n"
        return ""
      }
	  
	  
      //Function to validate the ID field
      function validateID(field)
      {
        if (field == "") return "No ID was entered.\n"
		else if (! /[0-9]/.test(field))
          return "ID number may only contain numbers. No letters or special characters allowed\n"
        else if (field.length != 13)
          return "ID number should contain 13 digits .\n"

        return ""
      }
	  
	  
      //Function to validate the date of birth field
      function validateDOB(field)
      {
        if (field == "") 
		{
			return "No date of birth was entered.\n"
		}
			
		else if (field.length == 10)
		{
							
			var d = parseInt(field.substr(0,2));
			var m = parseInt(field.substr(3,2));
			var y = parseInt(field.substr(6,4));
			var date = new Date();
			var curYear = date.getFullYear();
			var curMonth = date.getMonth();
			var curDay = date.getDate();
			
			if((field.charAt(2) != "/")||(field.charAt(5) != "/"))
			{
				return "Please enter your birthday in the following format: dd/mm/yyyy. /'s should be included\n"
			}
			else if ((d < 0 || d >31)||(m < 0 || m > 12)||(y > curYear))
			{
				
				return "Please enter your birthday in the following format: dd/mm/yyyy. Make sure to enter a valid date\n"
			}
		}
		else
		{
			return "Please enter your birthday in the following format: dd/mm/yyyy. /'s should be included\n"
		}
		
		
		return ""
      }
	  
	  
	  //Function to validate the date of birth against the ID number
	  function validateIDagainstDOB(fieldID, fieldDOB)
      {
		  
		    //get info from birthday
		  	var dDOB = parseInt(fieldDOB.substr(0,2));
			var mDOB = parseInt(fieldDOB.substr(3,2));
			var yDOB = parseInt(fieldDOB.substr(8,2));
			
			//get info from ID
			var yID = parseInt(fieldID.substr(0,2));
			var mID = parseInt(fieldID.substr(2,2));
			var dID = parseInt(fieldID.substr(4,2));
			
			if ((dDOB == dID)&&(mDOB == mID)&&(yDOB == yID))
			{
				return ""
			}
			
			else
			{
				return "Your birthday does not match the first 6 digits in your ID.\n"
			}
      }
	  
	  
	  //Function to clear all fields
	  function ClearFields() 
	  {

		document.getElementById("nameField").value = "";
		document.getElementById("surnameField").value = "";
		document.getElementById("idField").value = "";
		document.getElementById("dobField").value = "";
	 
		document.getElementById("nameErrField").innerHTML = "";
		document.getElementById("surnameErrField").innerHTML = "";
		document.getElementById("idErrField").innerHTML = "";
		document.getElementById("dobErrField").innerHTML = "";
		document.getElementById("submitErrField").innerHTML = "";
	 
	  }