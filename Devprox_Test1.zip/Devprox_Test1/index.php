<!DOCTYPE html>
<html>
  <head>
	
	<link href='https://fonts.googleapis.com/css?family=Sniglet|Raleway:900' rel='stylesheet'>
	<link rel="stylesheet" type="text/css" href="mystyle.css">
	<script src="validate.js"></script>
	<?php require_once("login.php");?>
	<?php require_once("validate.php");?>
	
	
    <title>DEVPROX TEST 1</title>
  
  </head>
  
  
  <body>
  
	<noscript>
		<h2 class = "error">JavaScript is disabled! Please enable JavaScript in your web browser for the best experience! Some functionality may not work otherwise</h2>
	</noscript>
  


	<div align="center" class ="signup">
      <h2 align="center">Signup Form</h2>
		<h3 align="center" class = "error" id="submitErrField"><?php echo $submitErr?></h3>
      <form method="post" action="index.php" onsubmit="return validate(this)" autocomplete="on">
	    
		  <div align="center">
		  <label>Your Name</label>
          <input id="nameField" type="text" placeholder="Name" maxlength="32" name="name" value="<?php echo $name;?>" required autofocus>
		  <label id="nameErrField" class = "error"> <?php echo $nameErr;?> </label>
		  </div>
		  
		  <div align="center">
		  <label>Your Surname</label>
          <input id="surnameField" type="text" placeholder="Surname" maxlength="32" name="surname" value="<?php echo $surname;?>" required>
		  <label id="surnameErrField" class = "error"> <?php echo $surnameErr;?>  </label>
		  </div>
		  
		  <div align="center">
		  <label>Your ID number</label>
          <input id="idField" type="text" placeholder="ID number" maxlength="13" name="id" value="<?php echo $id;?>" required  autocomplete="on">
		  <label id="idErrField" class = "error"> <?php echo $idErr;?> </label>
		  </div>

		  <div align="center">
		  <label>Your birthday</label>
		  <input id="dobField" type="text" name="dob" value="<?php echo $dob;?>" required placeholder="dd/mm/yyyy" title="dd/mm/yyyy  i.e. 25/08/1985">
		  <label id="dobErrField" class = "error"> <?php echo $dobErr;?>  </label>
		  </div>
      
		  <div align="center">
		  <input type="submit" value="POST">
		  <button type="button" onclick="ClearFields();">CANCEL</button>
		  </div>
		  
      </form>
	</div>
  </body>
</html>
