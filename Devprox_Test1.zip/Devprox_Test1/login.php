	<?php
	
	$servername = 'localhost';
	$username = 'root';
	$password = '';
	$dbname = 'dbdevproxtest1';
	$tablename = 'person';
	
	?>